"""Student Performance Analytics System
A beginner-friendly Python project using Pandas and NumPy.
Run from the project root: python main.py
"""
from pathlib import Path
import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "students.csv"
OUTPUT_DIR = BASE_DIR / "outputs"
SUBJECTS = ["Python", "Statistics", "SQL", "Data_Visualization", "NumPy"]
PASS_MARK = 40
ATTENDANCE_WARNING = 75


def load_data(file_path=DATA_FILE):
    """Load student records and validate the required columns."""
    data = pd.read_csv(file_path)
    required = ["Student_ID", "Name", "Department", *SUBJECTS, "Attendance_Percent"]
    missing = [column for column in required if column not in data.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {', '.join(missing)}")
    if data.empty:
        raise ValueError("The student dataset is empty.")
    if data[SUBJECTS].isna().any().any():
        raise ValueError("Subject marks contain missing values. Please correct students.csv.")
    if not data[SUBJECTS].apply(lambda col: col.between(0, 100).all()).all():
        raise ValueError("Subject marks must be between 0 and 100.")
    if not data["Attendance_Percent"].between(0, 100).all():
        raise ValueError("Attendance must be between 0 and 100.")
    return data


def calculate_results(data):
    """Return a copy with totals, averages, grades, pass/fail and attendance status."""
    results = data.copy()
    results["Total_Marks"] = results[SUBJECTS].sum(axis=1)
    results["Average_Marks"] = results[SUBJECTS].mean(axis=1).round(2)
    results["Grade"] = results["Average_Marks"].apply(assign_grade)
    # A student passes only if they score at least PASS_MARK in every subject.
    results["Result"] = np.where((results[SUBJECTS] >= PASS_MARK).all(axis=1), "Pass", "Fail")
    results["Attendance_Status"] = np.where(
        results["Attendance_Percent"] >= ATTENDANCE_WARNING, "Satisfactory", "Low Attendance"
    )
    return results


def assign_grade(average):
    """Assign a grade using the project's defined average-mark boundaries."""
    if average >= 90:
        return "A+"
    if average >= 80:
        return "A"
    if average >= 70:
        return "B"
    if average >= 60:
        return "C"
    if average >= 50:
        return "D"
    if average >= PASS_MARK:
        return "E"
    return "F"


def subject_analysis(data):
    """Summarize subject averages and highest/lowest scores."""
    rows = []
    for subject in SUBJECTS:
        rows.append({
            "Subject": subject.replace("_", " "),
            "Average_Marks": round(float(np.mean(data[subject].to_numpy())), 2),
            "Highest_Marks": int(data[subject].max()),
            "Lowest_Marks": int(data[subject].min()),
        })
    return pd.DataFrame(rows).sort_values("Average_Marks", ascending=False)


def print_section(title):
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def run_analysis(data):
    """Print the required class, student and subject analysis."""
    results = calculate_results(data)
    print_section("STUDENT PERFORMANCE ANALYTICS SYSTEM")
    print(f"Records: {len(results)} | Departments: {results['Department'].nunique()} | Subjects: {len(SUBJECTS)}")
    print("\nSTUDENT RESULTS")
    print(results[["Student_ID", "Name", "Department", "Total_Marks",
                   "Average_Marks", "Grade", "Result", "Attendance_Status"]].to_string(index=False))

    print_section("CLASS SUMMARY")
    print(f"Overall class average: {results['Average_Marks'].mean():.2f}%")
    print(f"Highest student average: {results['Average_Marks'].max():.2f}%")
    print(f"Lowest student average: {results['Average_Marks'].min():.2f}%")
    print(f"Students passed: {(results['Result'] == 'Pass').sum()}")
    print(f"Students failed: {(results['Result'] == 'Fail').sum()}")
    print(f"Students with attendance below {ATTENDANCE_WARNING}%: "
          f"{(results['Attendance_Percent'] < ATTENDANCE_WARNING).sum()}")

    print_section("SUBJECT-WISE ANALYSIS")
    subject_stats = subject_analysis(data)
    print(subject_stats.to_string(index=False))

    print_section("TOP PERFORMERS")
    top_students = results.nlargest(5, "Average_Marks")
    print(top_students[["Student_ID", "Name", "Department", "Average_Marks", "Grade"]].to_string(index=False))

    print_section("DEPARTMENT-WISE AVERAGE")
    department_stats = results.groupby("Department")["Average_Marks"].mean().round(2).sort_values(ascending=False)
    print(department_stats.to_string())

    OUTPUT_DIR.mkdir(exist_ok=True)
    results.to_csv(OUTPUT_DIR / "student_results.csv", index=False)
    subject_stats.to_csv(OUTPUT_DIR / "subject_analysis.csv", index=False)
    print(f"\nReports saved in: {OUTPUT_DIR.relative_to(BASE_DIR)}/")
    return results


def main():
    try:
        data = load_data()
        run_analysis(data)
    except (FileNotFoundError, pd.errors.ParserError, ValueError) as error:
        print(f"Could not run the analysis: {error}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
