# Project Documentation: Student Performance Analytics System

## 1. Project Title and Student Details

**Project title:** Student Performance Analytics System  
**Student name:** [Enter your full name]  
**Course:** Python with AI  
**Student ID / batch:** [Enter if required]  
**GitHub repository:** [Paste your repository URL after publishing]

## 2. Objective

The objective is to build a Python-based system that reads student marks and attendance from a CSV dataset and turns the records into an understandable performance summary. It calculates total and average marks, grades, pass/fail results, subject-wise statistics and top performers.

## 3. Technologies Used

- **Python:** variables, conditions, loops, functions and program flow.
- **Pandas:** reads CSV data into a DataFrame, organizes columns, calculates statistics, groups departments and exports results.
- **NumPy:** performs numerical operations and assigns pass/fail and attendance labels using `np.where`.

## 4. Dataset Description

The project includes 20 fictional sample records. Each record contains a student ID, name, department, marks in five subjects (Python, Statistics, SQL, Data Visualization and NumPy), and attendance percentage. Marks and attendance are represented on a 0–100 scale.

## 5. Implementation

1. `load_data()` reads `data/students.csv` with Pandas and validates required columns, missing subject marks and value ranges.
2. `calculate_results()` makes a copy of the dataset and calculates total marks and average marks for each student.
3. `assign_grade()` assigns a grade based on the student's average.
4. A student is marked `Pass` only if every subject mark is at least 40; otherwise the result is `Fail`.
5. Attendance below 75% is labeled `Low Attendance`.
6. `subject_analysis()` loops through the subject columns and calculates average, highest and lowest marks using NumPy and Pandas.
7. `run_analysis()` displays student results, overall class statistics, subject analysis, top five performers and department-wise averages.
8. The program exports the processed student table and subject summary as CSV files inside `outputs/`.

## 6. Key Features

- CSV loading and basic data validation.
- Total and average calculation.
- Rule-based grade assignment.
- Pass/fail and attendance checks.
- Class-level highest, lowest and average performance.
- Subject-wise and department-wise analysis.
- Top five performers.
- Exportable CSV reports.

## 7. Output / Screenshots

After running `python main.py`, capture a screenshot of the terminal showing:
- the student results table;
- class summary;
- subject-wise analysis and top performers.

Add your own screenshot files here if required by your instructor. The output CSV reports are generated automatically when the program runs.

## 8. Final Outcome

The system transforms a raw student CSV file into a structured performance report. It demonstrates basic Python programming, reusable functions, loops, conditions, NumPy numerical operations and Pandas data analysis without using advanced machine learning.

## 9. Challenges and Learning

**Example reflection — edit this to match your real experience:**
- Learned how to read CSV files into a Pandas DataFrame.
- Practiced calculating totals and averages for multiple records.
- Used conditions to apply grade and pass/fail rules consistently.
- Used NumPy and Pandas to summarize subject performance.
- Learned to organize a small project for GitHub and export analysis results.

## 10. GitHub Repository

**Repository URL:** [Paste your public GitHub URL here]

Before submitting, confirm the repository contains `main.py`, `data/students.csv`, `README.md`, `requirements.txt` and this documentation file. Run the project successfully and submit the repository link through the course Google Form.
