# Student Performance Analytics System

A beginner-friendly Python data-analysis project for the **Python with AI** assignment. It uses Python, NumPy and Pandas to summarize student marks, assign grades, identify pass/fail status, analyze subjects and find top performers.

> **Dataset note:** `data/students.csv` contains 20 fictional sample student records created for demonstration. Replace it with your own approved dataset if your instructor requires one.

## Features

- Loads student records from a CSV file into a Pandas DataFrame.
- Validates required columns and checks that marks and attendance are between 0 and 100.
- Calculates total and average marks for each student.
- Assigns grades using the rule below.
- Identifies pass/fail students.
- Summarizes highest, lowest and average performance.
- Performs subject-wise and department-wise analysis.
- Lists the top five performers.
- Exports detailed results to CSV files in `outputs/`.

## Technologies

- Python 3.10 or newer
- Pandas
- NumPy

## Project structure

```text
student-performance-analytics/
├── data/
│   └── students.csv
├── docs/
│   └── Project_Documentation.md
├── outputs/                  # Generated when you run the program
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Grading and pass rules

Grades are based on each student's average across the five subjects:

| Average marks | Grade |
|---:|:---|
| 90–100 | A+ |
| 80–89.99 | A |
| 70–79.99 | B |
| 60–69.99 | C |
| 50–59.99 | D |
| 40–49.99 | E |
| Below 40 | F |

A student **passes only when they score at least 40 in every subject**. Attendance below 75% is flagged as `Low Attendance`. These are project-defined rules, not official institutional grading policies.

## Setup and run

1. Install Python 3.10+.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. (Recommended) create and activate a virtual environment.
5. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

6. Run the program:

   ```bash
   python main.py
   ```

The program prints the student results, class summary, subject analysis, top five performers and department averages. It creates `outputs/student_results.csv` and `outputs/subject_analysis.csv`.

## Dataset columns

| Column | Description |
|---|---|
| `Student_ID` | Unique sample student identifier |
| `Name` | Student name (fictional) |
| `Department` | Academic department |
| `Python` | Marks out of 100 |
| `Statistics` | Marks out of 100 |
| `SQL` | Marks out of 100 |
| `Data_Visualization` | Marks out of 100 |
| `NumPy` | Marks out of 100 |
| `Attendance_Percent` | Attendance percentage |

## Google Form submission

After uploading and checking the repository, copy the public repository URL and paste it into the Google Form provided by your course. The course assignment says the deadline is **15 October 2026**. Add your actual repository URL to the documentation once the repository exists.

## Before submission

- [ ] Run `python main.py` and check that it completes without errors.
- [ ] Read the code and make sure you can explain the functions, loops, conditions, NumPy and Pandas operations.
- [ ] Review the grading and pass rules with your instructor if needed.
- [ ] Add your name and student details to the documentation.
- [ ] Add screenshots of your own program output if required.
- [ ] Push all project files to GitHub and verify the repository.
- [ ] Submit the GitHub URL using the course Google Form.
